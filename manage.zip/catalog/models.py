from django.db import models
from mysite import settings

class Category(models.Model):
    last_modified = models.DateTimeField(auto_now=True)
    name = models.TextField(null=False)


class Product(models.Model):
    product_status = (
        ('A', 'Active'),
        ('I', 'Inactive'),
    )

    category = models.ForeignKey(
        'Category',
        on_delete=models.CASCADE,
        null=False
    )
    last_modified = models.DateTimeField(auto_now=True)
    status = models.TextField(db_index=True, choices=product_status, default='A', null=False)
    name = models.TextField(null=False)
    description = models.TextField(null=False)
    price = models.DecimalField(max_digits=12, decimal_places=2, null=False)
    quantity=models.IntegerField(default=2, null=False)
    reorder_trigger=models.IntegerField(default=0, null=False)
    reorder_quantity=models.IntegerField(default=5, null=False)

    def image_url(self):
        pimage = ProductImage.objects.filter(product = self.id).first()
        if pimage is None:
            return settings.STATIC_URL + "catalog/media/products/media/products/" + "notfound.jpg"
        return settings.STATIC_URL + "catalog/media/products/media/products/" + pimage.filename

    def images_url(self):
        images_url=[]
        return images_url

    def images_urls(self):
        pimages = ProductImage.objects.filter(product=self)
        image_urls=[]

        for p in pimages:
            image_urls.append(p.image_url())

        if image_urls.count == 0:
            image_urls[0] = settings.STATIC_URL + "catalog/media/products/media/products/notfound.jpg"
        return image_urls

class ProductImage(models.Model):
    filename = models.TextField()
    product = models.ForeignKey(
        'Product',
        on_delete=models.CASCADE,
        null=False
    )
    last_modified = models.DateTimeField(auto_now=True)

    def image_url(self):
        self.url = "notfound.jpg"
        if self.filename is not None:
            self.url = settings.STATIC_URL + "catalog/media/products/media/products/" + self.filename
        return self.url